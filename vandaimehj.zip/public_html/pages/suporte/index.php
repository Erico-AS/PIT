<!DOCTYPE html>
<html lang="Pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="main.css">
    <title>Formap</title>
</head>
<body>
    <header>
        <nav class="navigation">
            <img src="../../images/material-logodeitada-semfundo.png" alt="logodeitada">
            <ul class="nav-menu">
                <li class="nav-item"><a href="../../index.html">Home</a></li>
                <li class="nav-item"><a href="../../pages/inicio/index.php">Foruns</a></li>
                <li class="nav-item"><a href="../../index.html#about-us">About</a></li>
                <li class="nav-item"><a href="../../pages/suporte/index.php">Support</a></li>
                <li class="nav-item"><a href="../../pages/login/index.php">Login</a></li>
                <li class="nav-item"><a href="../../pages/mapa/index.php">Mapa</a></li>

            </ul>
            <div class="menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </nav>
    </header>
    <main>
        <section class="home">
            <div class="home-text">
                <h4 class="text-h4">Bem vindo ao Suporte!</h4>
                <h1 class="text-h1">Encontre respostas para suas perguntas aqui</h1>
                <p>Consulte as perguntas frequentes (FAQs)!</p>
                <button onclick="scrollToBottom()" class="home-btn">Fale Conosco!</button>
                
            </div>
            <div class="home-img">
                <img src=../../images/undraw_Travel_plans_re_103r.png>
            </div>
        </section>
        
        <section class="form" id="contact">
            <h2 class="sup">Contate-nos</h2>
            <form id="content" action="envioFormulario.php" method="POST">
                <label for="name">Nome:</label>
                <input type="text" id="name" name="name" required>
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                
                <label for="message">Mensagem:</label>
                <textarea id="message" name="message" required></textarea>
                
                <input type="submit" value="Enviar">
            </form>
        </section>
        
        <section class="faq">
            <h2 class="hh2">Perguntas frequentes</h2>
            <div class="faq-item">
                <h3>Como faço para encontrar passagens aéreas baratas?</h3>
                <p> Pesquise em sites de comparação de voos e reserve com antecedência para obter melhores preços.</p>
            </div>
            <div class="faq-item">
                <h3>Quando devo começar a procurar passagens e fazer reservas?</h3>
                <p>Comece a procurar com 2-3 meses de antecedência para voos internacionais e 1-2 meses para voos domésticos.</p>
            </div>
            <div class="faq-item">
                <h3>Quais são os documentos necessários para reservar um voo?</h3>
                <p> Geralmente, você precisa do nome exato no passaporte para reservar e viajar.</p>
            </div>
            <div class="faq-item">
                <h3>Como posso comparar preços de hotéis e escolher acomodações adequadas?</h3>
                <p>Use sites de reservas para comparar preços, localização e avaliações de hotéis.</p>
            </div>
            <div class="faq-item">
                <h3>Como posso organizar o transporte do aeroporto para o hotel?</h3>
                <p>Reserve transferências com antecedência ou use táxis confiáveis.</p>
            </div>
            <div class="faq-item">
                <h3>Quais são os principais itens que devo incluir na minha lista de embalagem?</h3>
                <p>Itens essenciais incluem documentos, roupas adequadas, medicamentos e eletrônicos.</p>
            </div>
            <div class="faq-item">
                <h3>Preciso de vacinas específicas para o destino da minha viagem?</h3>
                <p>Verifique as exigências de vacinas para o destino e agende com antecedência.</p>
            </div>
            <div class="faq-item">
                <h3>Como posso lidar com questões de segurança, como proteger meus pertences pessoais?</h3>
                <p>Use bolsas seguras e mantenha cópias de documentos importantes.</p>
            </div>
            <div class="faq-item">
                <h3>Qual é a política de cancelamento e reembolso de reservas de hotéis e voos?</h3>
                <p>Leia atentamente as políticas de cancelamento de hotéis e voos.</p>
            </div>
            <div class="faq-item">
                <h3>Como devo lidar com a conversão de moeda estrangeira?</h3>
                <p>Use caixas eletrônicos locais para taxas melhores ou cartões de viagem.</p>
            </div>
            
        </section>
    </main>
    
    <script src="script.js"></script>
</body>
</html>