<?php
session_start();
include_once('../../service/config.php');

$conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// Verifica a conexão
if ($conexao->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conexao->connect_error);
}

// Obter os dados do formulário
$titulo = $_POST['titulo'];
if (!empty($titulo)) {
    $texto = $_POST['texto'];
    $autor = $_SESSION['nome_user'];
    $sql = "SELECT id FROM user WHERE nome_user = '$autor'";
    $resultado = $conexao->query($sql);
    $row = $resultado->fetch_row();
    $idUser = $row[0];
    $idUser = intval($idUser);

    // Escapar caracteres especiais
    $titulo = $conexao->real_escape_string($titulo);
    $texto = $conexao->real_escape_string($texto);

    // Inserir os dados no banco de dados
    $sql = "INSERT INTO publi (titulo, texto, fk_id_user) VALUES ('$titulo', '$texto', $idUser)";

    if ($conexao->query($sql) === TRUE) {
        // Redirecionar para a página de visualização dos dados
        header("Location: forum.php");
        exit();
    } else {
        echo "Erro ao salvar os dados: " . $conexao->error;
    }
} else {
    echo "<script>alert('Título não pode ser vazio')</script>";
    echo "<script>window.location.href = 'publicar.php';</script>";
    exit();
}
$conexao->close();
?>
