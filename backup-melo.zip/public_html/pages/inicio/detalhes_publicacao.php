<?php
// Verifica se o parâmetro "id" está presente na URL
if (isset($_GET['id'])) {
    // Obter o ID da publicação selecionada
    $id = $_GET['id'];

    session_start();
    include_once('../../service/config.php');

    // Verifica a conexão
    if ($conexao->connect_error) {
        die("Falha na conexão com o banco de dados: " . $conexao->connect_error);
    }

    // Obter os detalhes do título e do texto da publicação
    $sql = "SELECT titulo, texto, autor FROM publi WHERE id = '$id'";
    $result = $conexao->query($sql);

    if ($result !== false && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $titulo = isset($row["titulo"]) ? $row["titulo"] : "";
        $texto = isset($row["texto"]) ? $row["texto"] : "";
        $autor = isset($row["autor"]) ? $row["autor"] : "";

        echo "<h1>" . $titulo . "</h1>";
        echo "<p>" . $texto . "</p>";
        echo "<p>" . $autor . "</p>";

        if (isset($_SESSION['nome_user'])) {
            $usuarioLogado = $_SESSION['nome_user'];

            $sqlCurtida = "SELECT id FROM curtidas WHERE id_publicacao = '$id' AND usuario = '$usuarioLogado'";
            $resultCurtida = $conexao->query($sqlCurtida);

            if ($resultCurtida !== false && $resultCurtida->num_rows > 0) {
                echo "<p>Você já curtiu esta publicação.</p>";
            } else {
                echo "<a href='curtir_publicacao.php?id=" . $id . "'>Curtir</a>";
            }
            
            if ($_SESSION['nome_user'] == $autor) {
                echo '<a href="editar_publicacao.php?id=' . $id . '"><img src="o pedra.png" alt="Editar"></a>';
            }
        }
    } else {
        echo "Nenhum dado encontrado.";
    }

    $conexao->close();
} else {
    echo "ID não fornecido na URL.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Fóruns</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
    <style>
        /* Estilos CSS adicionais */
    </style>
</head>
<body>
    <<header>
        <nav class="navigation">
            <img src="../../images/material-logodeitada-semfundo.png" alt="logodeitada">
            <ul class="nav-menu">
                <li class="nav-item"><a href="../../index.html">Home</a></li>
                <li class="nav-item"><a href="index.php">Forums</a></li>
                <li class="nav-item"><a href="../../index.html#about-us">About</a></li>
                <li class="nav-item"><a href="../../pages/suporte/index.html">Support</a></li>
                <li class="nav-item"><a href="../../pages/login/index.php">Login</a></li>
            </ul>
            <div class="menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </nav>
    </header>

    <main class="main-detalhes">
        <div class="container-detalhes">
            <?php
            if ($result !== false && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $titulo = isset($row["titulo"]) ? $row["titulo"] : "";
                $texto = isset($row["texto"]) ? $row["texto"] : "";

                echo "<h1>" . $titulo . "</h1>";
                echo "<p>" . $texto . "</p>";
                echo "<a href='forum.php' class='btn-acessar'>Voltar</a>";
            } else {
                echo "Nenhum dado encontrado.";
            }
            ?>
        </div>
    </main>
</body>
</html>
