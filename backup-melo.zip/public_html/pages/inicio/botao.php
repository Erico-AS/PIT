<!--<?php 
 //session_start();
 //include_once('../../service/config.php');

 //$publicado = $_SESSION['titulo'];

 //$sql = "SELECT * FROM publi ORDER BY id DESC"; 
 
 //$result = $conexao->query($sql);

?>-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!--<?php 
        //echo"<script>A publicação foi concluída com sucesso('$publicado');</script>";
    ?>-->
    <a href="publicar.php">+</a>
    <a href="index.php">Voltar</a>
</body>
</html>